---
external help file: ModuleBuildToolsTemp-help.xml
Module Name: ModuleBuildToolsTemp
online version:
schema: 2.0.0
---

# Get-MBTSpecialPath

## SYNOPSIS
Get SpecialFolder defined in Environment variables

## SYNTAX

```
Get-MBTSpecialPath [<CommonParameters>]
```

## DESCRIPTION
Get SpecialFolder defined in Environment variables

## EXAMPLES

### EXAMPLE 1
```
Get-MBTSpecialPath
```

## PARAMETERS

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
