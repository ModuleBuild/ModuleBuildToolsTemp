﻿---
external help file: ModuleBuildToolsTemp-help.xml
Module Name: ModuleBuildToolsTemp
online version: https://github.com/zloeber/ModuleBuild
schema: 2.0.0
---

# Get-ErrorInfo

## SYNOPSIS
TBD

## SYNTAX

```
Get-ErrorInfo [[-errorRecord] <ErrorRecord>] [<CommonParameters>]
```

## DESCRIPTION
TBD

## EXAMPLES

### EXAMPLE 1
```
TBD
```

\[Diagnostics.CodeAnalysis.SuppressMessageAttribute("PS", "",Scope="function",Justification="")\]

## PARAMETERS

### -errorRecord
TBD

```yaml
Type: ErrorRecord
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
